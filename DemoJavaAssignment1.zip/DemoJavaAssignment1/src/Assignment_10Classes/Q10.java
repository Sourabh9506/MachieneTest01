package Assignment_10Classes;

import java.util.Scanner;

//C/Ob2/ 10. If a five-digit number is given, 
//write a program to reverse the number.
//You can set the status of your assignment here.

public class Q10 {

	public static void main(String[] args) {
		Scanner scn=new Scanner(System.in);
		
		System.out.println("Enter the number"
				+ "");
		int num=scn.nextInt();
		
		   long sum = 0;
	        
	        while(num > 0) {
	            
	            sum = (sum * 10) + (num % 10);
	            num = (num / 10);
	            
	        }
	        System.out.println();
	        System.out.println("The reverse of digits is :" + sum);
	    }

		
	}


