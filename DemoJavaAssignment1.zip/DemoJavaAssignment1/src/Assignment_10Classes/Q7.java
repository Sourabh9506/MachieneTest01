package Assignment_10Classes;

import java.util.Scanner;

//C/Ob2/ 7. Raju�s basic salary is given. 
//His dearness allowance is 40% of the basic salary and house rent 
//allowance is 20%. Calculate his total salary.
//You can set the status of your assignment here.

public class Q7 {

	public static void main(String[] args) {
	  
		inputFromUser();
	
	}
	public static void inputFromUser(){
		
	    Scanner scn=new Scanner(System.in);
	    
	    System.out.println("Enter raju base salary");
	    
	    double baseSalary=scn.nextDouble();
		double dearnessAllowance=0.4*baseSalary;
		double rentAllowance=0.2*baseSalary;
		
		double totalSalary= baseSalary+dearnessAllowance+rentAllowance;
		
		System.out.println("Raju total salary : "+totalSalary);
	}
	

}
