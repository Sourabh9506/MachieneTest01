package Assignment_10Classes;

//C/Ob2/ 6. Two numbers are stored in locations i and j. 
//Write a program to interchange the numbers.
//You can set the status of your assignment here.

public class Q6 {

	public static void main(String[] args) {
		int i=10,j=20;
		System.out.println("i : "+i+" j : "+j);
		int temp=i;
		i=j;
		j=temp;
		
		System.out.println("i and j after swapping are ");
		System.out.println("i :"+i+" j :"+j);
		
	}

}
