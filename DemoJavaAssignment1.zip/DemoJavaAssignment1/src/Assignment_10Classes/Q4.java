package Assignment_10Classes;

import java.util.Scanner;


//C/Ob2/ 4. The distance between two cities (KM) is input through the keyboard. 
//Write a program to convert and print this distance in meters, feet, 
//inches and centimeters.

public class Q4 {

	public static void main(String[] args) {
		inputFromUser();

	}
	public static void inputFromUser(){
		Scanner scn=new Scanner(System.in);
		
		System.out.print("Enter the distance(KM) between two cities");
		int distance=scn.nextInt();
		scn.close();
		
		int meters=distance*100;
		float inches=(float) (39.37*meters);
		float feet=(float) (3.281*meters);
		float centimeter=100000*distance;
		
		System.out.print("Distance in meters :"+meters);
		System.out.println("Distance in inches :"+inches);
		System.out.println("Distance in feet : "+feet);
	    System.out.println("Distance in centimetres :"+centimeter);
		
		
		
		
	}

}
