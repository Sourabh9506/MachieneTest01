package Assignment_10Classes;

import java.util.Scanner;

//C/Ob2/ 9. If a five-digit number is input through the keyboard, 
//write a program to calculate the sum of its digits.

public class Q9 {

	public static void main(String[] args) {
		inputNumber();

	}
	public static void inputNumber(){
		Scanner scn=new Scanner(System.in);
		
		System.out.println("Enter five digit number : ");
		int number=scn.nextInt();
		
		scn.close();
		int sum=0;
		
		while(number>0)
		{
		sum+=number%10;
		
	     number=number/10;
		}
		System.out.println("Sum of 5 digit is : "+sum);
	}

}
