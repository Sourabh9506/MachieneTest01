package Assignment_10Classes;

public class Q1 {

	public static void main(String[] args) {
		
		int numOfOranges=10;
		int price=45;
		
		float priceOf1Orange;
		priceOf1Orange=price/numOfOranges;
		System.out.println(priceOf1Orange);
	}

}
