package Assignment_10Classes;

//C/Ob2/ 2. Ramu visited the bookstore to buy books for his kid.
//He bought notebooks for Rs.100 and magic pot for Rs.50. 
//How much money did Ramu spend in the bookstore?

public class Q2 {

	public static void main(String[] args) {

		int totalSpend=100+50;
		System.out.println("Raju spent "
				+totalSpend);
	}

}
