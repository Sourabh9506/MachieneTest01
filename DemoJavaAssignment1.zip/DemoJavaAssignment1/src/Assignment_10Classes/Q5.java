package Assignment_10Classes;

import java.util.Scanner;

//C/Ob2/ 5. The temperature of a city in Fahrenheit is given. 
//Write a program to convert it into Celsius.
//You can set the status of your assignment here.

public class Q5 {

	public static void main(String[] args) {
		inputFromUser();

	}
	public static void inputFromUser(){
		
		Scanner scn=new Scanner(System.in);
		
		System.out.print("Enter temp in Fahrenheit : ");
		int fahrenheit=scn.nextInt();
		
		int celcius=(int) ((fahrenheit-32)*.5556);
		
		System.out.println("Temperature in celcius is : "+celcius);
	}

}
