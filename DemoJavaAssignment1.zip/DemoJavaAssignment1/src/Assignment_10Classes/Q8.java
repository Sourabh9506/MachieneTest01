package Assignment_10Classes;

//C/Ob2/ h. Implement a logic to swap two numbers without using a 
//temporary variable.
//You can set the status of your assignment here.

public class Q8 {

	public static void main(String[] args) {
		int i=9;
		int j=8;
		System.out.println("i : "+i+" j : "+j);
	    
		i=i*j;
		j=i/j;
		i=i/j;
		System.out.println("i : "+i+" j : "+j);
		
	}

}
