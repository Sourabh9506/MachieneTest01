package Assignment_10Classes;

import java.util.Scanner;

public class Q3 {

	public static void main(String[] args) {

		inputFromUser();
		
	}
	public static void inputFromUser(){
		
		Scanner scn=new Scanner(System.in);
		
		System.out.print("Enter first number : ");
		int num1=scn.nextInt();
		
		System.out.print("Enter second number : ");
		int num2=scn.nextInt();
		
		scn.close();
		
		int remainder=num1%num2;
		int quotient=num1/num2;
		
		System.out.print("Remainder is : "+remainder);
		System.out.println("Quotient is : "+ quotient);
	}

}
