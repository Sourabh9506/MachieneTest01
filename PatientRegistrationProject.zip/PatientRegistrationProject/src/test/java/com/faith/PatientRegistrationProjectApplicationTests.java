package com.faith;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatientRegistrationProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
