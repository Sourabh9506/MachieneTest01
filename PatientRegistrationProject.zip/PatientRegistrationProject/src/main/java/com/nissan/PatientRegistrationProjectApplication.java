package com.nissan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatientRegistrationProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatientRegistrationProjectApplication.class, args);
		System.out.println("Patient application starts");
	}

}
