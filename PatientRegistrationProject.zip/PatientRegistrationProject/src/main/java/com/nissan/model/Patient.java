package com.nissan.model;


import java.time.LocalDate;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Tbl_Patient")




public class Patient {
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="Patient_Id")
	private Integer Patient_id;
	
	@Column(name="Registration_No")
	private String RegistrationNo;
	
	@Column(name="Patient_Name")
	private String patientName;
	
	@Column(name="Date_Of_Birth")
	private LocalDate dateOfBirth;
	
	@Column(name="Gender")
	private String gender;
	
	@Column(name="Address")
	private String address;
	
	@Column(name="Phone_No")
	private Long PhoneNo;

	
	public Patient(String registrationNo, String patientName, LocalDate dateOfJoining, String gender, String address,
			Long phoneNo) {
		super();
		RegistrationNo = registrationNo;
		this.patientName = patientName;
		this.dateOfBirth = dateOfBirth;
		this.gender = gender;
		this.address = address;
		PhoneNo = phoneNo;
	}

	public Patient(String patientName, String address, Long phoneNo) {
		super();
		this.patientName = patientName;
		this.address = address;
		PhoneNo = phoneNo;
	}
	
	
	
	public Integer getPatient_id() {
		return Patient_id;
	}

	public void setPatient_id(Integer patient_id) {
		Patient_id = patient_id;
	}

	public String getRegistrationNo() {
		return RegistrationNo;
	}

	public void setRegistrationNo(String registrationNo) {
		RegistrationNo = registrationNo;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfJoining(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Long getPhoneNo() {
		return PhoneNo;
	}

	public void setPhoneNo(Long phoneNo) {
		PhoneNo = phoneNo;
	}


	

}
