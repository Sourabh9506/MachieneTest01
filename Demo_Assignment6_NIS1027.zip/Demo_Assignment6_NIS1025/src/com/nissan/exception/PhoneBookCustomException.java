package com.nissan.exception;

@SuppressWarnings("serial")
public class PhoneBookCustomException extends Exception {
	
	public PhoneBookCustomException(String message) {
		super(message);
	}
}
