package com.nissan.service;

import java.util.List;

import com.nissan.model.Professor;

public interface IProfessorService {
	
	Professor addNewProfessor(Professor professor);
	
	Professor removeProfessor(int professorId);
	
	Professor getProfessorById(int professorId);
	
	List<Professor> getAllProfessor();
	
	Professor updateeSalaryById(int professorId,double salary);
	
	

}
