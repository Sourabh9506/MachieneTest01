package com.nissan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProfessorMonitoringSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
