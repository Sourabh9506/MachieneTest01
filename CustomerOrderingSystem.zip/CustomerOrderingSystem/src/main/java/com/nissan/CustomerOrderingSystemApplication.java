package com.nissan;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerOrderingSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerOrderingSystemApplication.class, args);
	}

}
