package com.nissan.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.nissan.dao.CustomerDao;
import com.nissan.dao.OrderDao;
import com.nissan.dao.OrderItemDao;
import com.nissan.model.Customer;
import com.nissan.model.Order;
import com.nissan.model.OrderItem;

@Service
@Transactional
public class OrderItemServiceImpl implements IOrderItemService{

	@Autowired
	private OrderItemDao orderItemDao;
	
	@Autowired
	private CustomerDao customerDao;
	
	@Autowired 
	private OrderDao orderDao;
	
	@Override
	public OrderItem getOrderItemById(Integer orderItemId) {
		
		return (OrderItem)orderItemDao.findById(orderItemId).orElse(null);
	}

	@Override
	public List<OrderItem> getOrderListByCustNo(Integer custNo) {

		Customer customer=customerDao.findById(custNo).orElse(null);
		
		if (customer == null) {
			return null;
		} else {
			List<Order> orderList = orderDao.findByCustNo(custNo);
			List<OrderItem> resultList = new ArrayList<>();
			for (Order order : orderList) {
				List<OrderItem> orderItemList = orderItemDao.findByOrderNo(order);
				for (OrderItem orderItem : orderItemList) {
					resultList.add(orderItem);
				}
			}
			return resultList;
			
		}
		
	}

}