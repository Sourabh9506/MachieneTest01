package com.nissan.service;

import java.util.List;

import com.nissan.model.Order;

public interface IOrderService {
	
	Order getOrderById(Integer ordrId);
	
	List<Order> getAllOrdersByCustNo(Integer custNo);

}
