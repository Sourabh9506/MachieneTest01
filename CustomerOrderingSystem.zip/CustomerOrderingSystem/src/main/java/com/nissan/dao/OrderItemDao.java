package com.nissan.dao;

import java.util.List;

import org.springframework.data.jpa.repository.support.JpaRepositoryImplementation;
import org.springframework.stereotype.Repository;

import com.nissan.model.Order;
import com.nissan.model.OrderItem;

@Repository
public interface OrderItemDao extends JpaRepositoryImplementation<OrderItemDao, Integer>{

	List<OrderItem> findByOrderNo(Order order);
}
