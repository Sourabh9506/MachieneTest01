package com.nissan.model;

import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name="tblOrder")
public class Order {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private int orderNo;
	
	private int custNo;
	
	@ManyToOne
	@JoinColumn(name="custNo",insertable=false,updatable=false)
	public Customer customer;
	
	private LocalDate orderDate;
	

	//default Constructor
	public Order() {
		super();
		// TODO Auto-generated constructor stub
	}


    //parameterised constructor
	public Order(int custNo, LocalDate orderDate) {
		super();
		this.custNo = custNo;
		this.orderDate = orderDate;
	}

	
	
	@Override
	public String toString() {
		return "Order [orderNo=" + orderNo + ", custNo=" + custNo  + ", orderDate="
				+ orderDate + "]";
	}

	
	
	
	
}
