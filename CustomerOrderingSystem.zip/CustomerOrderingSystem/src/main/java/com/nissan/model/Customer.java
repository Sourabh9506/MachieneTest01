package com.nissan.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
@Entity
@Table(name= "tblCustomer")
public class Customer {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer custNo;
	
	private String custnoName;
	
	private String Address;
	
	// default constructor
	
	public Customer(){
		super();
		// TODO Auto-generated constructor stub
	}
	
	// parameterized constructors
	public Customer(String custnoName, String address) {
		
		this.custnoName = custnoName;
		Address = address;
	}
	
	
	//getters and setters

	public Integer getCustNo() {
		return custNo;
	}

	public void setCustNo(Integer custNo) {
		this.custNo = custNo;
	}

	public String getCustnoName() {
		return custnoName;
	}

	public void setCustnoName(String custnoName) {
		this.custnoName = custnoName;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}
	
	
	
	

	//toString
	@Override
	public String toString() {
		return "Customer [custNo=" + custNo + ", custnoName=" + custnoName + ", Address=" + Address + "]";
	}

	
	
}

