package com.nissan.model;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

public class OrderItem {
	
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Integer itemId;
	
	private Integer orderNo;

	@ManyToOne
	@JoinColumn(name = "orderNo", insertable = false, updatable = false)
	private Order order;
	
	private String itemName;
	
	private Integer quantity;

	
	//default constructor
	public OrderItem() {
		super();
		// TODO Auto-generated constructor stub
	}

	//parameterized constructors
	public OrderItem(Integer orderNo, String itemName, Integer quantity) {
		this.orderNo = orderNo;
		this.itemName = itemName;
		this.quantity = quantity;
	}

	//getters and setters
	public Integer getItemId() {
		return itemId;
	}

	public void setItemId(Integer itemId) {
		this.itemId = itemId;
	}


	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public Integer getQuantity() {
		return quantity;
	}

	public void setQuantity(Integer quantity) {
		this.quantity = quantity;
	}

	//toString method
	@Override
	public String toString() {
		return "OrderItem [itemId=" + itemId +  ", orderNo=" + orderNo + ", itemName=" + itemName
				+ ", quantity=" + quantity + "]";
	}


}
