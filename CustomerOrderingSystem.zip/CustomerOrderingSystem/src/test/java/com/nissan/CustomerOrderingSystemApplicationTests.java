package com.nissan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CustomerOrderingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
